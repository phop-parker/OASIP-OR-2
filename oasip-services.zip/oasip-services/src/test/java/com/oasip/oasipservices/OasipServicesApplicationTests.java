package com.oasip.oasipservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OasipServicesApplicationTests {

    @Test
    void contextLoads() {
    }

}
