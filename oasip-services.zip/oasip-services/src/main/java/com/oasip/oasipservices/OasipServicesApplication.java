package com.oasip.oasipservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OasipServicesApplication {

    public static void main(String[] args) {
        SpringApplication.run(OasipServicesApplication.class, args);
    }

}
